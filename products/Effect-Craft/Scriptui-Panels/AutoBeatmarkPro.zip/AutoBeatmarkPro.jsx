/*
* Decompiled with Jsxer
* Version: 1.7.4
* JSXBIN 2.0
*/

(function (thisObj) {
function buildUI(obj) {
function font(c, n, s, sz) {
try {
c.graphics.font = ScriptUI.newFont(n, s, sz);
} catch (e) {
}
}
function color(c, rgb) {
try {
c.graphics.foregroundColor = c.graphics.newPen(c.graphics.PenType.SOLID_COLOR, [rgb[0], rgb[1], rgb[2], 1], 1);
} catch (e) {
}
}
function rr(g, x, y, ww, h, rd, f) {
g.newPath();
g.moveTo(x + rd, y);
g.lineTo((x + ww) - rd, y);
g.lineTo(x + ww, y + rd);
g.lineTo(x + ww, (y + h) - rd);
g.lineTo((x + ww) - rd, y + h);
g.lineTo(x + rd, y + h);
g.lineTo(x, (y + h) - rd);
g.lineTo(x, y + rd);
g.closePath();
if (f) { 
g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, f));
}
}
// A rounded rectangle with real arcs: four quarter circles joined by the sides.
function rrect(g, x, y, ww, hh, rd, fill, stroke, sw) {
if (ww <= 0 || hh <= 0) { 
return;
}
var r = Math.max(0, Math.min(rd, Math.min(ww, hh) / 2));
var cs = [[x + r, y + r, Math.PI, Math.PI * 1.5], [x + ww - r, y + r, Math.PI * 1.5, Math.PI * 2], [x + ww - r, y + hh - r, 0, Math.PI * 0.5], [x + r, y + hh - r, Math.PI * 0.5, Math.PI]];
g.newPath();
var first = true;
for (var c = 0; c < 4; c += 1) { 
var cc = cs[c];
for (var s = 0; s <= 5; s += 1) { 
var a = cc[2] + ((cc[3] - cc[2]) * (s / 5));
var px = cc[0] + (Math.cos(a) * r);
var py = cc[1] + (Math.sin(a) * r);
if (first) { 
g.moveTo(px, py);
first = false;
}
else {
g.lineTo(px, py);
}
}}
g.closePath();
if (fill) { 
g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, fill));
}
if (stroke) { 
g.strokePath(g.newPen(g.PenType.SOLID_COLOR, stroke, sw ? sw : 1));
}
}
function sec(parent, title) {
var g = parent.add("group");
g.orientation = "column";
g.alignment = ["fill", "top"];
g.alignChildren = ["fill", "top"];
g.spacing = 0;
g.margins = [0, 8, 0, 0];
var tr = g.add("group");
tr.alignment = ["fill", "top"];
tr.alignChildren = ["left", "top"];
tr.margins = [0, 0, 0, 3];
var tl = tr.add("statictext", undefined, title);
tl.alignment = ["left", "top"];
tl.preferredSize = [-1, 13];
font(tl, "Arial", "Bold", 9);
color(tl, A.accentBright);
var sp = g.add("group");
sp.alignment = ["fill", "top"];
sp.preferredSize = [-1, 1];
sp.maximumSize = [9999, 1];
sp.onDraw = function () {
var gg = this.graphics;
gg.rectPath(0, 0, this.size[0], 1);
gg.fillPath(gg.newBrush(gg.BrushType.SOLID_COLOR, [A.sepColor[0], A.sepColor[1], A.sepColor[2], 1]));
};
var ct = g.add("group");
ct.orientation = "column";
ct.alignment = ["fill", "top"];
ct.alignChildren = ["fill", "top"];
ct.spacing = 4;
ct.margins = [0, 7, 0, 4];
return ct;
}
function refresh() {
try {
w.layout.layout(true);
} catch (e) {
}
$.sleep(1);
}
function setDot(c) {
dCol = [c[0], c[1], c[2], 1];
try {
dot.notify("onDraw");
} catch (e) {
}
}
function setSt(msg, type) {
stTxt.text = msg;
if (type === "ok") { 
setDot(A.green);
color(stTxt, A.green);
}
else if (type === "warn") {
setDot(A.orange);
color(stTxt, A.orange);
}
else if (type === "err") {
setDot(A.red);
color(stTxt, A.red);
}
else {
setDot([0.5, 0.5, 0.5]);
color(stTxt, A.textNormal);
}
}
function setProg(f, m) {
pFrac = f;
if (m) { 
pTxt.text = m;
}
try {
pBar.notify("onDraw");
} catch (e) {
}
refresh();
}
function getTgt() {
return tDrop.selection ? tDrop.selection.index : 0;
}
function getCol() {
var i = cDrop.selection ? cDrop.selection.index : 0;
return CONFIG.markerColors[i].idx;
}
function updSt() {
var ly = U.getAudio();
if (ly) { 
setSt("Ready", "ok");
lyTxt.text = "\u266b  " + ly.name;
lastLy = ly;
}
else {
var c = app.project.activeItem;
if ((!c) || (!(c instanceof CompItem))) { 
setSt("No composition");
lyTxt.text = "";
}
else if (c.selectedLayers.length === 0) {
setSt("Select an audio layer");
lyTxt.text = "";
}
else if (c.selectedLayers.length > 1) {
setSt("Select one layer only");
lyTxt.text = "";
}
else {
setSt("Not an audio layer", "err");
lyTxt.text = c.selectedLayers[0].name;
}
}
var ti = getTgt();
rTgt.text = ti === 0 ? "Composition" : ti === 1 ? "Layer" : "Both";
refresh();
}
function analyze() {
if (busy) { 
return;
}
busy = true;
aBtn.enabled = false;
rBtn.enabled = false;
dBtn.enabled = false;
try {
var comp = app.project.activeItem;
if ((!comp) || (!(comp instanceof CompItem))) { 
throw new Error("No active composition.");
}
var al = U.getAudio();
if (!al) { 
throw new Error("Select one audio layer.\nSupported: MP3, WAV, AIFF, AAC, M4A");
}
lastLy = al;
var sens = sensC.val();
var minD = distC.val() / 1000;
var tgt = getTgt();
var col = getCol();
var pfx = CONFIG.markerPrefix;
var useNum = true;
app.beginUndoGroup(CONFIG.scriptName);
setProg(0.05, "Converting audio...");
setSt("Working...", "warn");
var amp = Data.convert(comp, al);
for (var i = 1; i <= comp.numLayers; i += 1) { 
comp.layer(i).selected = false;}
al.selected = true;
setProg(0.1, "Extracting data...");
var data = Data.extract(amp, setProg);
setProg(0.25, "Detecting beats...");
var beats = Det.run(data, sens, minD, setProg);
setProg(0.96, "Creating markers...");
var count = 0;
if ((tgt === 0) || (tgt === 2)) { 
count = Mk.addComp(comp, beats, col, pfx, useNum);
}
if ((tgt === 1) || (tgt === 2)) { 
count = Mk.addLayer(al, beats, col, pfx, useNum);
}
try {
amp.remove();
} catch (e) {
}
rBeats.text = String(count);
rDur.text = U.fmt(data.dur);
rBPM.text = (count > 1) && (data.dur > 0) ? "~" + Math.round(60 / (data.dur / (count - 1))) + " BPM" : "--";
rTgt.text = tgt === 0 ? "Composition" : tgt === 1 ? "Layer" : "Both";
setProg(1, count + " beats marked.");
setSt(count + " beats detected", "ok");
app.endUndoGroup();
} catch (err) {try {
app.endUndoGroup();
} catch (e2) {
}
setProg(0, "Error.");
setSt("Error", "err");
alert(CONFIG.scriptName + "\n\n" + err.message);
} finally {
busy = false;
aBtn.enabled = true;
rBtn.enabled = true;
dBtn.enabled = true;
refresh();
}
}
function delMk() {
if (busy) { 
return;
}
try {
var comp = app.project.activeItem;
if ((!comp) || (!(comp instanceof CompItem))) { 
alert("No composition.");
return;
}
var tgt = getTgt();
var tot = 0;
app.beginUndoGroup(CONFIG.scriptName + " - Delete");
if ((tgt === 0) || (tgt === 2)) { 
tot += Mk.delComp(comp);
}
if ((tgt === 1) || (tgt === 2)) { 
var ly = U.getAudio();
if ((!ly) && (lastLy)) { 
try {
if (lastLy.containingComp === comp) { 
ly = lastLy;
}
} catch (e) {
}
}
if ((!ly) && (comp.selectedLayers.length === 1)) { 
ly = comp.selectedLayers[0];
}
if (ly) { 
tot += Mk.delLayer(ly);
}
}
app.endUndoGroup();
rBeats.text = "0";
rBPM.text = "--";
setProg(0, tot + " markers deleted.");
setSt("Cleared", "ok");
} catch (err) {try {
app.endUndoGroup();
} catch (e2) {
}
alert(err.message);
}
}
var w = obj instanceof Panel ? obj : new Window("palette", "AutoBeatmarkPro", undefined, {resizeable: true});
w.orientation = "column";
w.alignment = ["fill", "fill"];
w.alignChildren = ["fill", "top"];
w.spacing = 0;
w.margins = [8, 4, 8, 8];
var A = CONFIG;
// EffectCraft paints ScriptUI controls itself and hands mouse events to the script
// (clientX / clientY relative to the control), so the slider can be drawn and driven
// by hand. Other hosts (After Effects) keep the native slider control.
var HOST_EC = (function () {
try {
return (typeof ScriptUI !== "undefined") && (String(ScriptUI.frameworkName) === "EffectCraft");
}
catch (e) {
return false;
}
})();
function mkSlider(parent, label, min, max, def, suffix) {
// The geometry of the drawn track.
var PAD = 9;
var GROOVE_H = 6;
var KNOB = 7;
var TRACK_H = 26;
function clampInt(v) {
var n = parseInt(v, 10);
if (isNaN(n)) {
n = min;
}
if (n < min) {
n = min;
}
if (n > max) {
n = max;
}
return n;
}
function parseNum(v) {
var n = parseInt(v, 10);
if (isNaN(n)) {
return null;
}
if (n < min) {
n = min;
}
if (n > max) {
n = max;
}
return n;
}
var wrap = parent.add("group");
wrap.orientation = "column";
wrap.alignment = ["fill", "top"];
wrap.alignChildren = ["fill", "top"];
wrap.spacing = 3;
wrap.margins = [0, 3, 0, 0];
var rowG = wrap.add("group");
rowG.alignment = ["fill", "top"];
rowG.alignChildren = ["left", "center"];
rowG.spacing = 6;
var lb = rowG.add("statictext", undefined, label);
lb.alignment = ["left", "center"];
lb.preferredSize = [170, 18];
font(lb, "Arial", "Regular", 9);
color(lb, A.textNormal);
var valG = rowG.add("group");
valG.alignment = ["right", "center"];
valG.alignChildren = ["left", "center"];
valG.spacing = 4;
var inp = valG.add("edittext", undefined, String(def));
inp.alignment = ["left", "center"];
inp.preferredSize = [40, 20];
inp.characters = 4;
font(inp, "Arial", "Regular", 9);
var sf = valG.add("statictext", undefined, suffix ? suffix : "");
sf.alignment = ["left", "center"];
sf.preferredSize = [16, 16];
font(sf, "Arial", "Regular", 9);
color(sf, A.textDim);
var state = clampInt(def);
var lastText = String(state);
var writing = false;
var dragging = false;
var hovering = false;
var native = null;
var trk = null;
// The one place the value changes: the field, the track and the native slider
// (when there is one) always follow it.
function setValue(v, fromField) {
var n = clampInt(v);
state = n;
if (!fromField) {
try {
inp.text = String(n);
}
catch (e) {
}
}
if (native) {
try {
writing = true;
native.value = n;
}
catch (e2) {
}
writing = false;
}
}
function trackW() {
try {
return trk.size[0];
}
catch (e) {
return 240;
}
}
// The pointer's x on the track -> the value.
function xToValue(x) {
var w = trackW();
var usable = Math.max(1, w - (PAD * 2));
var t = (x - PAD) / usable;
if (t < 0) {
t = 0;
}
if (t > 1) {
t = 1;
}
return Math.round(min + (t * (max - min)));
}
// The track: a groove, the part that is filled and the knob.
function paintTrack(ctl) {
var g = ctl.graphics;
var w = ctl.size[0];
if (!(w > 0)) {
return;
}
var span = max - min;
var t = span > 0 ? (state - min) / span : 0;
if (t < 0) {
t = 0;
}
if (t > 1) {
t = 1;
}
var gw = Math.max(4, w - (PAD * 2));
var gy = 5;
var kx = PAD + (t * gw);
var ky = gy + (GROOVE_H / 2);
var kr = dragging ? KNOB + 1 : KNOB;
var hot = hovering || dragging;
// The groove.
rrect(g, PAD, gy, gw, GROOVE_H, GROOVE_H / 2, [0.16, 0.15, 0.2, 1], null);
// The filled part.
if (t > 0) {
rrect(g, PAD, gy, Math.max(3, kx - PAD), GROOVE_H, GROOVE_H / 2, hot ? A.accentBright : A.accent, null);
}
// The knob's halo.
if (hot) {
g.newPath();
g.ellipsePath(kx - kr - 4, ky - kr - 4, (kr + 4) * 2, (kr + 4) * 2);
g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, [A.accent[0], A.accent[1], A.accent[2], 0.25]));
}
// The knob.
g.newPath();
g.ellipsePath(kx - kr, ky - kr, kr * 2, kr * 2);
g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, [0.96, 0.95, 1, 1]));
g.newPath();
g.ellipsePath(kx - kr, ky - kr, kr * 2, kr * 2);
g.strokePath(g.newPen(g.PenType.SOLID_COLOR, [A.accentBright[0], A.accentBright[1], A.accentBright[2], 1], 2));
// The range, at the ends of the track.
var f9 = ScriptUI.newFont("dialog", "Regular", 9);
var dim = g.newPen(g.PenType.SOLID_COLOR, [A.textVeryDim[0], A.textVeryDim[1], A.textVeryDim[2], 1], 1);
var lo = String(min);
var hi = String(max);
var whi = 0;
try {
whi = g.measureString(hi, f9).width;
}
catch (e3) {
}
g.drawString(lo, dim, PAD, gy + GROOVE_H + 3, f9);
g.drawString(hi, dim, w - PAD - whi, gy + GROOVE_H + 3, f9);
}
if (HOST_EC) {
// The drawn track: it takes the pointer itself.
trk = wrap.add("group");
trk.alignment = ["fill", "top"];
trk.alignChildren = ["fill", "top"];
trk.preferredSize = [-1, TRACK_H];
trk.margins = [0, 1, 0, 0];
trk.onDraw = function () {
paintTrack(this);
};
trk.addEventListener("mousedown", function (e) {
if (e.button !== 0) {
return;
}
dragging = true;
setValue(xToValue(e.clientX), false);
});
trk.addEventListener("mousemove", function (e) {
if (!dragging) {
return;
}
setValue(xToValue(e.clientX), false);
});
trk.addEventListener("mouseup", function (e) {
if (!dragging) {
return;
}
dragging = false;
setValue(xToValue(e.clientX), false);
});
trk.addEventListener("mouseover", function () {
hovering = true;
});
trk.addEventListener("mouseout", function () {
hovering = false;
});
}
else {
native = wrap.add("slider", undefined, state, min, max);
native.alignment = ["fill", "top"];
native.preferredSize = [320, 14];
native.onChanging = function () {
if (writing) {
return;
}
setValue(Math.round(native.value), false);
};
native.onChange = function () {
if (writing) {
return;
}
setValue(Math.round(native.value), false);
};
}
// The value typed in the field: it follows the track, and the track follows it.
inp.onChanging = function () {
var txt = String(inp.text);
if (txt === lastText) {
return;
}
var n = parseNum(txt);
if (n === null) {
return;
}
lastText = txt;
setValue(n, true);
};
inp.onChange = function () {
lastText = String(state);
try {
inp.text = lastText;
}
catch (e4) {
}
};
return {input: inp, label: lb, slider: native, track: trk, val: function () {
return state;
}, set: function (v) {
setValue(v, false);
}};
}

function mkHint(parent, txt) {
var h = parent.add("statictext", undefined, txt);
h.alignment = ["left", "top"];
font(h, "Arial", "Italic", 8);
color(h, [0.56, 0.46, 0.74]);
return h;
}
function mkRes(parent, label, def) {
var r = parent.add("group");
r.alignment = ["fill", "top"];
r.alignChildren = ["left", "center"];
r.spacing = 0;
var l = r.add("statictext", undefined, label);
l.alignment = ["left", "center"];
l.preferredSize = [66, 17];
font(l, "Arial", "Regular", 9);
color(l, A.textDim);
var v = r.add("statictext", undefined, def);
v.alignment = ["left", "center"];
font(v, "Arial", "Regular", 9);
color(v, A.textBright);
return v;
}
function styleBtn(b, txt, big) {
var ok = false;
try {
ok = (typeof b.graphics.drawString) === "function";
} catch (e0) {
ok = false;
}
if (!ok) {
return;
}
b.onDraw = function () {
var g = this.graphics;
var BW = this.size[0];
var BH = this.size[1];
var live = this.enabled !== false;
var rc = 3;
g.newPath();
g.moveTo(rc, 0);
g.lineTo(BW - rc, 0);
g.lineTo(BW, rc);
g.lineTo(BW, BH - rc);
g.lineTo(BW - rc, BH);
g.lineTo(rc, BH);
g.lineTo(0, BH - rc);
g.lineTo(0, rc);
g.closePath();
g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, live ? [0.125, 0.112, 0.148, 1] : [0.155, 0.145, 0.165, 1]));
g.rectPath(0.5, 0.5, BW - 1, BH - 1);
g.strokePath(g.newPen(g.PenType.SOLID_COLOR, live ? (big ? [0.55, 0.33, 0.88, 1] : [0.30, 0.27, 0.37, 1]) : [0.26, 0.25, 0.30, 1], 1));
var tw = txt.length * (big ? 6.3 : 5.9);
try {
var ms = g.measureString(txt);
if (ms && ms.width) {
tw = ms.width;
}
} catch (e1) {
}
var ty = Math.round((BH - (big ? 14 : 12)) / 2) + 1;
try {
g.drawString(txt, g.newPen(g.PenType.SOLID_COLOR, live ? (big ? [0.80, 0.62, 1, 1] : [0.80, 0.78, 0.88, 1]) : [0.45, 0.43, 0.50, 1], 1), Math.round((BW - tw) / 2), ty);
} catch (e2) {
}
};
}
function fitW() {
try {
var WW = w.size[0];
var inner = Math.max(200, WW - 16);
// The name gives way to the value: label + gap + value box + unit = the width.
var lw = Math.max(80, inner - 68);
sensC.label.preferredSize = [lw, 18];
distC.label.preferredSize = [lw, 18];
if (sensC.slider) {
sensC.slider.preferredSize = [Math.max(120, inner), 14];
}
if (distC.slider) {
distC.slider.preferredSize = [Math.max(120, inner), 14];
}
tDrop.preferredSize = [Math.max(120, inner - 62), 22];
cDrop.preferredSize = [Math.max(100, inner - 84), 22];
var half = Math.max(80, Math.floor((inner - 5) / 2));
dBtn.preferredSize = [half, 26];
rBtn.preferredSize = [half, 26];
} catch (e) {
}
}
var hg = w.add("group");
hg.alignment = ["fill", "top"];
hg.alignChildren = ["center", "top"];
hg.margins = [0, 4, 0, 10];
hg.spacing = 0;
var logoG = hg.add("group");
logoG.alignment = ["center", "top"];
logoG.preferredSize = [236, 68];
logoG.minimumSize = [236, 68];
logoG.maximumSize = [236, 68];
logoG.onDraw = function () {
var g = this.graphics;
var LW = this.size[0];
var LH = this.size[1];
function useFont(sz, style) {
try {
g.font = ScriptUI.newFont("Bahnschrift", style, sz);
} catch (e) {
}
}
function mw(t, sz) {
var m = null;
try {
m = g.measureString(t);
} catch (e) {
m = null;
}
if (m && m.width) {
return m.width;
}
return sz * 0.55 * t.length;
}
function mh(t, sz) {
var m = null;
try {
m = g.measureString(t);
} catch (e) {
m = null;
}
if (m && m.height) {
return m.height;
}
return Math.round(sz * 1.25);
}
function pen(c) {
var p = null;
try {
p = g.newPen(g.PenType.SOLID_COLOR, c, 1);
} catch (e) {
p = null;
}
return p;
}
function put1(t, x, top, c) {
var p = pen(c);
if (!p) {
return;
}
try {
g.drawString(t, p, Math.round(x), Math.round(top));
} catch (e) {
}
}
function putTracked(t, track, x, top, c, sz) {
var p = pen(c);
if (!p) {
return;
}
var prev = 0;
var i = 0;
var cx = x;
var fallback = sz * 0.55;
while (i < t.length) {
var prefix = t.substring(0, i + 1);
var tot = mw(prefix, sz);
var adv = tot - prev;
if (!(adv > 0)) {
adv = fallback;
}
prev = tot;
try {
g.drawString(t.charAt(i), p, Math.round(cx), Math.round(top));
} catch (e) {
}
cx += adv + track;
i += 1;
}
}
var ttl = "BEATMARKER PRO";
var ts = 24;
useFont(ts, "Bold");
while (ts > 12 && mw(ttl, ts) > LW - 18) {
ts -= 1;
useFont(ts, "Bold");
}
var tw = mw(ttl, ts);
var tx = Math.round((LW - tw) / 2);
var asz = Math.max(9, Math.round(ts * 0.44));
var ssz = Math.max(7, Math.round(ts * 0.31));
useFont(asz, "Bold");
var autoT = "AUTO";
var aW = mw(autoT, asz) + Math.round(asz * 0.34) * 3;
var aH = mh(autoT, asz);
useFont(ssz, "Regular");
var sigT = "made by ASHRAF";
var sW = mw(sigT, ssz);
var sH = mh(sigT, ssz);
useFont(ts, "Bold");
var tH = mh(ttl, ts);
var total = aH + 3 + tH + 2 + sH;
var top = Math.max(1, Math.round((LH - total) / 2));
var titleTop = top + aH + 3;
put1(ttl, tx, titleTop + 1, [0.14, 0.05, 0.18, 1]);
put1(ttl, tx, titleTop, [0.89, 0.45, 0.97, 1]);
useFont(asz, "Bold");
putTracked(autoT, Math.round(asz * 0.34), tx, top, [0.94, 0.88, 1, 1], asz);
useFont(ssz, "Regular");
put1(sigT, Math.round(tx + tw - sW), titleTop + tH + 1, [0.76, 0.70, 0.86, 1]);
};
var stC = sec(w, "STATUS");
var stR = stC.add("group");
stR.alignment = ["fill", "top"];
stR.alignChildren = ["left", "center"];
stR.spacing = 8;
var dot = stR.add("image", undefined, undefined, {name: "d"});
dot.preferredSize = [7, 7];
dot.minimumSize = [7, 7];
dot.maximumSize = [7, 7];
var dCol = [0.52, 0.49, 0.58, 1];
dot.onDraw = function () {
var g = this.graphics;
g.ellipsePath(0, 0, 7, 7);
g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, dCol));
};
var stTxt = stR.add("statictext", undefined, "Select an audio layer");
stTxt.alignment = ["left", "center"];
font(stTxt, "Arial", "Regular", 9);
color(stTxt, A.textNormal);
var lyTxt = stC.add("statictext", undefined, "");
lyTxt.alignment = ["left", "top"];
font(lyTxt, "Arial", "Regular", 8);
color(lyTxt, A.textDim);
var seC = sec(w, "SETTINGS");
var sensC = mkSlider(seC, "Sensitivity", 0, 100, CONFIG.defaultSensitivity, "%");
mkHint(seC, "Low \u2192 more beats        High \u2192 fewer beats");
var sp1 = seC.add("group");
sp1.preferredSize = [-1, 8];
sp1.alignment = ["fill", "top"];
var distC = mkSlider(seC, "Min Distance", 20, 500, CONFIG.defaultMinBeatDistance, "ms");
mkHint(seC, "Min gap between markers");
var opC = sec(w, "OPTIONS");
var tR = opC.add("group");
tR.alignment = ["fill", "top"];
tR.alignChildren = ["left", "center"];
tR.spacing = 8;
var tL = tR.add("statictext", undefined, "Target");
tL.alignment = ["left", "center"];
tL.preferredSize = [54, 18];
font(tL, "Arial", "Regular", 9);
color(tL, A.textNormal);
var tDrop = tR.add("dropdownlist", undefined, ["Composition", "Layer", "Both"]);
tDrop.selection = 0;
tDrop.alignment = ["fill", "center"];
tDrop.preferredSize = [400, 22];
var cR = opC.add("group");
cR.alignment = ["fill", "top"];
cR.alignChildren = ["left", "center"];
cR.spacing = 8;
var cL = cR.add("statictext", undefined, "Color");
cL.alignment = ["left", "center"];
cL.preferredSize = [54, 18];
font(cL, "Arial", "Regular", 9);
color(cL, A.textNormal);
var cNames = [];
for (var ci = 0; ci < CONFIG.markerColors.length; ci += 1) {
cNames.push(CONFIG.markerColors[ci].name);}
var cDrop = cR.add("dropdownlist", undefined, cNames);
cDrop.selection = 0;
cDrop.alignment = ["fill", "center"];
cDrop.preferredSize = [380, 22];
var cDot = cR.add("image", undefined, undefined, {name: "cd"});
cDot.preferredSize = [14, 14];
cDot.minimumSize = [14, 14];
cDot.maximumSize = [14, 14];
var pCol = CONFIG.previewColors[0];
cDot.onDraw = function () {
var g = this.graphics;
g.ellipsePath(1, 1, 12, 12);
g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, [pCol[0], pCol[1], pCol[2], 1]));
};
cDrop.onChange = function () {
var i = cDrop.selection ? cDrop.selection.index : 0;
pCol = (CONFIG.previewColors[i]) || (CONFIG.previewColors[0]);
try {
cDot.notify("onDraw");
} catch (e) {
}
refresh();
};
var prC = sec(w, "PROGRESS");
var pBar = prC.add("group");
pBar.alignment = ["fill", "top"];
pBar.preferredSize = [-1, 6];
pBar.minimumSize = [-1, 6];
pBar.maximumSize = [9999, 6];
var pFrac = 0;
pBar.onDraw = function () {
var g = this.graphics;
var bw = this.size[0];
var bh = this.size[1];
rr(g, 0, 0, bw, bh, 3, [A.barBg[0], A.barBg[1], A.barBg[2], 1]);
if (pFrac > 0) {
rr(g, 0, 0, Math.max(6, Math.round(bw * pFrac)), bh, 3, [A.barFill[0], A.barFill[1], A.barFill[2], 1]);
}
};
var pTxt = prC.add("statictext", undefined, "Ready");
pTxt.alignment = ["left", "top"];
font(pTxt, "Arial", "Regular", 8);
color(pTxt, A.textDim);
var rsC = sec(w, "RESULTS");
var rBeats = mkRes(rsC, "Beats", "0");
var rDur = mkRes(rsC, "Duration", "--");
var rBPM = mkRes(rsC, "Avg BPM", "--");
var rTgt = mkRes(rsC, "Target", "Composition");
var bSp = w.add("group");
bSp.preferredSize = [-1, 16];
bSp.alignment = ["fill", "top"];
var bG = w.add("group");
bG.orientation = "column";
bG.alignment = ["fill", "top"];
bG.alignChildren = ["fill", "top"];
bG.spacing = 6;
var aBtn = bG.add("button", undefined, "\u26a1  ANALYZE BEATS");
aBtn.alignment = ["fill", "top"];
aBtn.preferredSize = [-1, 32];
font(aBtn, "Arial", "Bold", 10);
styleBtn(aBtn, "\u26a1  ANALYZE BEATS", 1);
var bR = bG.add("group");
bR.alignment = ["fill", "top"];
bR.alignChildren = ["fill", "center"];
bR.spacing = 5;
var dBtn = bR.add("button", undefined, "\u2716  DELETE");
dBtn.alignment = ["fill", "center"];
dBtn.preferredSize = [200, 26];
font(dBtn, "Arial", "Regular", 9);
styleBtn(dBtn, "\u2716  DELETE", 0);
var rBtn = bR.add("button", undefined, "\u21bb  RE-ANALYZE");
rBtn.alignment = ["fill", "center"];
rBtn.preferredSize = [200, 26];
font(rBtn, "Arial", "Regular", 9);
styleBtn(rBtn, "\u21bb  RE-ANALYZE", 0);
var lastLy = null;
var busy = false;
aBtn.onClick = analyze;
rBtn.onClick = function () {
setProg(0, "Re-analyzing...");
refresh();
analyze();
};
dBtn.onClick = delMk;
tDrop.onChange = function () {
updSt();
};
aBtn.addEventListener("mouseover", function () {
updSt();
});
dBtn.addEventListener("mouseover", function () {
updSt();
});
rBtn.addEventListener("mouseover", function () {
updSt();
});
w.onShow = function () {
updSt();
};
w.layout.layout(true);
fitW();
w.layout.layout(true);
w.layout.resize();
w.onResizing = w.onResize = function () {
fitW();
this.layout.resize();
};
if (!(w instanceof Panel)) {
w.center();
w.show();
}
return w;
}
var CONFIG = {accent: [0.62, 0.42, 0.95], accentBright: [0.79, 0.47, 0.96], accentDim: [0.48, 0.32, 0.72], accentVeryDim: [0.35, 0.25, 0.52], barBg: [0.20, 0.17, 0.25], barFill: [0.72, 0.42, 0.97], defaultMinBeatDistance: 70, defaultSensitivity: 50, green: [0.45, 0.85, 0.55], markerColors: [{idx: 0, name: "Default"}, {idx: 1, name: "Red"}, {idx: 2, name: "Yellow"}, {idx: 3, name: "Aqua"}, {idx: 4, name: "Pink"}, {idx: 5, name: "Lavender"}, {idx: 6, name: "Peach"}, {idx: 7, name: "Sea Foam"}, {idx: 8, name: "Blue"}, {idx: 9, name: "Green"}, {idx: 10, name: "Purple"}, {idx: 11, name: "Orange"}, {idx: 12, name: "Brown"}, {idx: 13, name: "Fuchsia"}, {idx: 14, name: "Cyan"}, {idx: 15, name: "Sandstone"}, {idx: 16, name: "Dark Green"}], markerPrefix: "Beat ", orange: [1, 0.72, 0.35], previewColors: [[0.55, 0.55, 0.55], [1, 0.22, 0.22], [1, 0.88, 0.12], [0.22, 0.78, 0.82], [1, 0.42, 0.68], [0.68, 0.58, 0.88], [1, 0.68, 0.48], [0.38, 0.82, 0.58], [0.32, 0.52, 1], [0.32, 0.78, 0.32], [0.62, 0.32, 0.88], [1, 0.55, 0.18], [0.58, 0.38, 0.25], [0.88, 0.22, 0.58], [0.22, 0.82, 0.88], [0.78, 0.68, 0.48], [0.22, 0.48, 0.22]], red: [1, 0.42, 0.42], scriptName: "Peak Beat Marker", sepColor: [0.29, 0.22, 0.41], textBright: [0.95, 0.94, 0.97], textDim: [0.56, 0.52, 0.64], textNormal: [0.86, 0.84, 0.90], textVeryDim: [0.38, 0.35, 0.48], version: "4.0"};
var U = {clamp: function (v, mn, mx) {
var n = parseInt(v, 10);
return isNaN(n) ? mn : Math.max(mn, Math.min(mx, n));
}, findAmp: function (c) {
for (var i = c.numLayers; i >= 1; i--) { 
try {
if (c.layer(i).name === "Audio Amplitude") { 
return c.layer(i);
}
} catch (e) {
}}
return null;
}, fmt: function (s) {
var m = Math.floor(s / 60);
var sec = (s % 60).toFixed(2);
return m + ":" + parseFloat(sec) < 10 ? "0" : "" + sec;
}, getAudio: function () {
var c = app.project.activeItem;
if ((!c) || (!(c instanceof CompItem))) { 
return null;
}
var s = c.selectedLayers;
return (s.length === 1) && (this.isAudio(s[0])) ? s[0] : null;
}, isAudio: function (l) {
if (!l) { 
return false;
}
try {
if (l instanceof AVLayer) { 
if (l.hasAudio) { 
return true;
}
if ((l.source) && (l.source.hasAudio)) { 
return true;
}
if ((l.source) && (l.source.file)) { 
var e = l.source.file.name.split(".").pop().toLowerCase();
var ok = ["mp3", "wav", "aiff", "aac", "m4a", "wma", "ogg", "flac"];
for (var i = 0; i < ok.length; i += 1) { 
if (e === ok[i]) { 
return true;
}}
}
}
} catch (e) {
}
return false;
}};
var Data = {convert: function (comp, layer) {
for (var i = 1; i <= comp.numLayers; i += 1) { 
comp.layer(i).selected = false;}
layer.selected = true;
var ex = U.findAmp(comp);
if (ex) { 
ex.remove();
}
try {
app.executeCommand(app.findMenuCommandId("Convert Audio to Keyframes"));
} catch (e) {throw new Error("Convert Audio to Keyframes failed.");
}
$.sleep(500);
var a = U.findAmp(comp);
if (!a) { 
throw new Error("Audio Amplitude layer not created.");
}
return a;
}, extract: function (amp, cb) {
var sl = null;
try {
var ef = amp.property("ADBE Effect Parade");
if (ef) { 
for (var i = 1; i <= ef.numProperties; i += 1) { 
var e = ef.property(i);
if ((e.name === "Both Channels") || (e.name === "both channels")) { 
try {
sl = e.property("ADBE Slider Control-0001");
} catch (x) {
}
if (!sl) { 
try {
sl = e.property(1);
} catch (x2) {
}
}
break ;
}}
if (!sl) { 
for (var j = 1; j <= ef.numProperties; j += 1) { 
var ts = null;
try {
ts = ef.property(j).property("ADBE Slider Control-0001");
} catch (x3) {
}
if (!ts) { 
try {
ts = ef.property(j).property(1);
} catch (x4) {
}
}
if ((ts) && (ts.numKeys > 0)) { 
sl = ts;
break ;
}}
}
}
} catch (e2) {throw new Error("Cannot read amplitude.");
}
if (!sl) { 
throw new Error("No slider found.");
}
var nk = sl.numKeys;
if (nk < 10) { 
throw new Error("Too few keyframes (" + nk + ").");
}
var t = [];
var v = [];
var uf = Math.max(1, Math.floor(nk / 60));
for (var k = 1; k <= nk; k += 1) { 
t.push(sl.keyTime(k));
v.push(sl.keyValue(k));
if ((cb) && ((k % uf) === 0)) { 
cb((k / nk) * 0.25, "Extracting " + k + "/" + nk);
}}
var d = t[t.length - 1] - t[0];
return {dur: d, n: nk, rate: d > 0 ? nk / d : nk, times: t, values: v};
}};
var Sig = {athresh: function (v, w, mult) {
var n = v.length;
var th = [];
var h = Math.floor(w / 2);
for (var i = 0; i < n; i += 1) { 
var s = (i - h) > 0 ? i - h : 0;
var e = (i + h) < (n - 1) ? i + h : n - 1;
var c = (e - s) + 1;
var ls = 0;
for (var j = s; j <= e; j++) { 
ls += v[j];}
var lm = ls / c;
var lq = 0;
for (var k = s; k <= e; k++) { 
var d = v[k] - lm;
lq += (d * d);}
var lsd = Math.sqrt(lq / c);
th[i] = lm + (mult * lsd);}
return th;
}, deriv: function (v, t) {
var n = v.length;
var d = [];
d[0] = 0;
if (n > 1) { 
d[n - 1] = 0;
}
for (var i = 1; i < n - 1; i += 1) { 
var dt = t[i + 1] - t[i - 1];
d[i] = dt > 0 ? (v[i + 1] - v[i - 1]) / dt : 0;}
return d;
}, deriv2: function (v, t) {
var n = v.length;
var d = [];
d[0] = 0;
if (n > 1) { 
d[n - 1] = 0;
}
for (var i = 1; i < n - 1; i += 1) { 
var dt1 = t[i] - t[i - 1];
var dt2 = t[i + 1] - t[i];
var dt = (dt1 + dt2) / 2;
d[i] = dt > 0 ? ((v[i + 1] - (2 * v[i])) + v[i - 1]) / (dt * dt) : 0;}
return d;
}, energy: function (v, w) {
var n = v.length;
var e = [];
var h = Math.floor(w / 2);
for (var i = 0; i < n; i += 1) { 
var sq = 0;
var c = 0;
var s = (i - h) > 0 ? i - h : 0;
var nd = (i + h) < (n - 1) ? i + h : n - 1;
for (var j = s; j <= nd; j++) { 
sq += (v[j] * v[j]);
c++;}
e[i] = Math.sqrt(sq / c);}
return e;
}, flux: function (v, w) {
var n = v.length;
var f = [];
f[0] = 0;
for (var i = 1; i < n; i += 1) { 
var d = v[i] - v[i - 1];
f[i] = d > 0 ? d : 0;}
return this.mavg(f, (w) || (3));
}, gauss: function (v, w, passes) {
if (!passes) { 
passes = 1;
}
var result = v;
for (var pass = 0; pass < passes; pass += 1) { 
var n = result.length;
var r = [];
var h = Math.floor(w / 2);
var sg = Math.max(0.5, h / 2);
var k = [];
var ks = 0;
for (var i = 0; i < w; i += 1) { 
var x = i - h;
k[i] = Math.exp(-(x * x) / (2 * sg * sg));
ks += k[i];}
for (var j = 0; j < w; j += 1) { 
k[j] /= ks;}
for (var a = 0; a < n; a += 1) { 
var ws = 0;
var vs = 0;
for (var b = -h; b <= h; b++) { 
var idx = a + b;
if ((idx >= 0) && (idx < n)) { 
var wt = k[b + h];
vs += (result[idx] * wt);
ws += wt;
}}
r[a] = vs / ws;}
result = r;}
return result;
}, mavg: function (v, w) {
var n = v.length;
var r = [];
var h = Math.floor(w / 2);
var rs = 0;
var rc = 0;
for (var i = 0; i <= Math.min(h, n - 1); i += 1) { 
rs += v[i];
rc++;}
r[0] = rs / rc;
for (var j = 1; j < n; j += 1) { 
var a = j + h;
if (a < n) { 
rs += v[a];
rc++;
}
var b = (j - h) - 1;
if (b >= 0) { 
rs -= v[b];
rc--;
}
r[j] = rs / rc;}
return r;
}, multiBandEnergy: function (values, windowSize) {
var n = values.length;
var lowBand = [];
var highBand = [];
var heavySmooth = this.mavg(values, windowSize * 3);
var lightSmooth = this.mavg(values, 3);
for (var i = 0; i < n; i += 1) { 
lowBand[i] = heavySmooth[i];
highBand[i] = lightSmooth[i] - heavySmooth[i];
if (highBand[i] < 0) { 
highBand[i] = 0;
}}
return {high: highBand, low: lowBand};
}, onsetStrength: function (values, times, smoothed) {
var n = values.length;
var flux = this.flux(smoothed, 3);
var d1 = this.deriv(smoothed, times);
var result = [];
for (var i = 0; i < n; i += 1) { 
var hwr = d1[i] > 0 ? d1[i] : 0;
result[i] = (flux[i] * 0.6) + (hwr * 0.4);}
return result;
}, onsetThresh: function (onset, w, mult) {
var n = onset.length;
var th = [];
var h = Math.floor(w / 2);
for (var i = 0; i < n; i += 1) { 
var s = (i - h) > 0 ? i - h : 0;
var e = (i + h) < (n - 1) ? i + h : n - 1;
var c = (e - s) + 1;
var local = [];
for (var j = s; j <= e; j++) { 
local.push(onset[j]);}
local.sort(function (a, b) {
return a - b;
});
var localMedian = local[Math.floor(c * 0.5)];
var localP75 = local[Math.floor(c * 0.75)];
var localMax = local[c - 1];
var localMean = 0;
for (var k = 0; k < c; k += 1) { 
localMean += local[k];}
localMean /= c;
var dev = 0;
for (var m = 0; m < c; m += 1) { 
var dd = local[m] - localMean;
dev += (dd * dd);}
dev = Math.sqrt(dev / c);
th[i] = localMedian + (mult * dev);}
return th;
}, stats: function (v) {
var n = v.length;
if (!n) { 
return null;
}
var sum = 0;
var mn = Infinity;
var mx = -Infinity;
for (var i = 0; i < n; i += 1) { 
sum += v[i];
if (v[i] < mn) { 
mn = v[i];
}
if (v[i] > mx) { 
mx = v[i];
}}
var mean = sum / n;
var sqd = 0;
for (var j = 0; j < n; j += 1) { 
var d = v[j] - mean;
sqd += (d * d);}
var sd = Math.sqrt(sqd / n);
var s = v.slice(0).sort(function (a, b) {
return a - b;
});
var med = (n % 2) === 0 ? (s[(n / 2) - 1] + s[n / 2]) / 2 : s[Math.floor(n / 2)];
var rmsSum = 0;
for (var r = 0; r < n; r += 1) { 
rmsSum += (v[r] * v[r]);}
var rms = Math.sqrt(rmsSum / n);
return {dr: mx - s[Math.floor(n * 0.1)], iqr: s[Math.floor(n * 0.75)] - s[Math.floor(n * 0.25)], max: mx, mean: mean, median: med, min: mn, nf: s[Math.floor(n * 0.1)], p25: s[Math.floor(n * 0.25)], p5: s[Math.floor(n * 0.05)], p75: s[Math.floor(n * 0.75)], p90: s[Math.floor(n * 0.9)], p95: s[Math.floor(n * 0.95)], rms: rms, sd: sd};
}};
var Det = {run: function (data, sens, minD, cb) {
var t = data.times;
var v = data.values;
var n = v.length;
if (n < 20) { 
return [];
}
if (cb) { 
cb(0.26, "Computing statistics...");
}
var st = Sig.stats(v);
var segLen = Math.max(50, Math.floor(n / 8));
var segStats = [];
for (var seg = 0; seg < n; seg += segLen) { 
var segEnd = Math.min(seg + segLen, n);
var segVals = v.slice(seg, segEnd);
segStats.push(Sig.stats(segVals));}
if (cb) { 
cb(0.3, "Multi-pass smoothing...");
}
var smLight = Sig.gauss(v, 3, 1);
var smMed = Sig.gauss(v, 5, 2);
var bw = Math.min(n, Math.max(15, Math.floor(data.rate * 0.5)));
if ((bw % 2) === 0) { 
bw++;
}
var baseline = Sig.mavg(v, bw);
var longEnv = Sig.mavg(v, Math.min(n, Math.max(31, Math.floor(data.rate * 2))));
if (cb) { 
cb(0.35, "Extracting features...");
}
var d1 = Sig.deriv(smLight, t);
var d2 = Sig.deriv2(smLight, t);
var ew = Math.max(3, Math.floor(data.rate * 0.025));
var localEnergy = Sig.energy(v, ew);
var wideEnergy = Sig.energy(v, Math.max(5, Math.floor(data.rate * 0.1)));
var spectralFlux = Sig.flux(smLight, 3);
var onsetStr = Sig.onsetStrength(v, t, smLight);
var bands = Sig.multiBandEnergy(v, Math.max(5, Math.floor(data.rate * 0.05)));
if (cb) { 
cb(0.42, "Adaptive thresholding...");
}
var sn = sens / 100;
var bm = 0.6 + (sn * 2.4);
var df = 1;
if (st.mean > 0) { 
var cv = st.sd / st.mean;
var crest = st.max / (st.rms + 0.001);
if ((cv > 1.5) && (crest > 3)) { 
df = 1.05;
}
else if (cv > 1) {
df = 1;
}
else if (cv > 0.5) {
df = 0.9;
}
else {
df = 0.75;
}
if (st.max < 5) { 
df *= 0.7;
}
else {
if (st.max < 15) { 
df *= 0.85;
}
}
}
var threshMult = bm * df;
var aw = Math.max(11, Math.floor(data.rate * 0.5));
if ((aw % 2) === 0) { 
aw++;
}
var ampThresh = Sig.athresh(smMed, aw, threshMult);
var onsetThreshW = Math.max(11, Math.floor(data.rate * 0.8));
if ((onsetThreshW % 2) === 0) { 
onsetThreshW++;
}
var onsetThresh = Sig.onsetThresh(onsetStr, onsetThreshW, threshMult * 0.6);
var globalMinAmp = st.nf + (st.sd * 0.3);
var highBandStats = Sig.stats(bands.high);
var globalMinOnset = 0;
if (highBandStats) { 
globalMinOnset = highBandStats.mean * 0.5;
}
if (cb) { 
cb(0.5, "Finding peak candidates...");
}
var nb = Math.max(2, Math.floor(data.rate * 0.012));
var cands = [];
for (var i = nb; i < (n - nb); i++) { 
var passAmp = (smMed[i] >= ampThresh[i]) || (smMed[i] >= (globalMinAmp * 2));
var passOnset = onsetStr[i] >= onsetThresh[i];
var passFlux = spectralFlux[i] > 0;
if (!passAmp) { 
continue ;
}
if ((!passOnset) && (!passFlux)) { 
continue ;
}
if (smMed[i] < (st.nf + (st.sd * 0.2))) { 
continue ;
}
var isMax = true;
for (var ni = -nb; ni <= nb; ni++) { 
if ((ni !== 0) && (smMed[i + ni] > smMed[i])) { 
isMax = false;
break ;
}}
if (!isMax) { 
continue ;
}
if (((i > 2) && (smLight[i] <= smLight[i - 1])) && (smLight[i - 1] <= smLight[i - 2])) { 
if (smMed[i] < st.p90) { 
continue ;
}
}
cands.push(i);}
if (cb) { 
cb(0.58, "Analyzing " + cands.length + " candidates...");
}
if (!cands.length) { 
return [];
}
var sw2 = Math.floor(data.rate * 0.3);
var slw = Math.max(1, Math.floor(data.rate * 0.008));
var pks = [];
for (var p = 0; p < cands.length; p += 1) { 
var ci = cands[p];
var pv = smMed[ci];
var lv = pv;
var rv = pv;
var ls = (ci - sw2) > 0 ? ci - sw2 : 0;
for (var li = ci - 1; li >= ls; li--) { 
if (smMed[li] < lv) { 
lv = smMed[li];
}
if (smMed[li] > pv) { 
break ;
}}
var rs = (ci + sw2) < (n - 1) ? ci + sw2 : n - 1;
for (var ri = ci + 1; ri <= rs; ri++) { 
if (smMed[ri] < rv) { 
rv = smMed[ri];
}
if (smMed[ri] > pv) { 
break ;
}}
var prom = pv - lv > rv ? lv : rv;
var slopeShort = 0;
var slopeMed = 0;
var slwMed = Math.max(1, Math.floor(data.rate * 0.02));
if ((ci - slw) >= 0) { 
var ds = t[ci] - t[ci - slw];
if (ds > 0.0001) { 
slopeShort = (smLight[ci] - smLight[ci - slw]) / ds;
}
}
if ((ci - slwMed) >= 0) { 
var dm = t[ci] - t[ci - slwMed];
if (dm > 0.0001) { 
slopeMed = (smLight[ci] - smLight[ci - slwMed]) / dm;
}
}
var bestSlope = Math.max(slopeShort, slopeMed);
var sharp = Math.abs(bestSlope);
if ((ci > 0) && (ci < (n - 1))) { 
var da = Math.abs(d1[ci]);
if (da > sharp) { 
sharp = da;
}
}
var curvature = (ci > 0) && (ci < (n - 1)) ? -d2[ci] : 0;
if (curvature < 0) { 
curvature = 0;
}
var energyRatio = wideEnergy[ci] > 0.001 ? localEnergy[ci] / wideEnergy[ci] : 1;
var highBandE = bands.high[ci];
var onset = onsetStr[ci];
var relLoud = pv - baseline[ci];
var relLongTerm = pv - longEnv[ci];
var segIdx = Math.min(Math.floor(ci / segLen), segStats.length - 1);
var localSt = segStats[segIdx];
var localRelative = localSt ? (pv - localSt.mean) / (localSt.sd + 0.001) : 0;
pks.push({curv: curvature, eng: localEnergy[ci], engRatio: energyRatio, flux: spectralFlux[ci], highE: highBandE, i: ci, localRel: localRelative, onset: onset, prom: prom, r: v[ci], relLong: relLongTerm, relLoud: relLoud, sc: 0, sharp: sharp, slope: bestSlope, t: t[ci], v: pv});}
if (cb) { 
cb(0.68, "Computing scores...");
}
var mx = {cur: 0.001, e: 0.001, er: 0.001, f: 0.001, he: 0.001, lr: 0.001, on: 0.001, p: 0.001, rl: 0.001, rlt: 0.001, sh: 0.001, sl: 0.001, v: 0.001};
for (var s = 0; s < pks.length; s += 1) { 
var pk = pks[s];
if (pk.v > mx.v) { 
mx.v = pk.v;
}
if (pk.prom > mx.p) { 
mx.p = pk.prom;
}
if (pk.sharp > mx.sh) { 
mx.sh = pk.sharp;
}
if (pk.curv > mx.cur) { 
mx.cur = pk.curv;
}
if (pk.eng > mx.e) { 
mx.e = pk.eng;
}
if (pk.engRatio > mx.er) { 
mx.er = pk.engRatio;
}
if (pk.highE > mx.he) { 
mx.he = pk.highE;
}
if (pk.onset > mx.on) { 
mx.on = pk.onset;
}
if (pk.flux > mx.f) { 
mx.f = pk.flux;
}
if (pk.relLoud > mx.rl) { 
mx.rl = pk.relLoud;
}
if (pk.relLong > mx.rlt) { 
mx.rlt = pk.relLong;
}
if (pk.localRel > mx.lr) { 
mx.lr = pk.localRel;
}
if (pk.slope > mx.sl) { 
mx.sl = pk.slope;
}}
for (var sc = 0; sc < pks.length; sc += 1) { 
var pp = pks[sc];
var sln = pp.slope > 0 ? pp.slope / mx.sl : 0;
var rln = pp.relLoud > 0 ? pp.relLoud / mx.rl : 0;
var rltn = pp.relLong > 0 ? pp.relLong / mx.rlt : 0;
var lrn = pp.localRel > 0 ? pp.localRel / mx.lr : 0;
pp.sc = (0.1 * (pp.v / mx.v)) + (0.18 * (pp.prom / mx.p)) + (0.14 * (pp.sharp / mx.sh)) + (0.04 * (pp.curv / mx.cur)) + (0.06 * sln) + (0.06 * (pp.eng / mx.e)) + (0.04 * (pp.engRatio / mx.er)) + (0.06 * (pp.highE / mx.he)) + (0.1 * (pp.onset / mx.on)) + (0.06 * (pp.flux / mx.f)) + (0.06 * rln) + (0.05 * rltn) + (0.05 * lrn);}
if (cb) { 
cb(0.74, "Filtering...");
}
var minProm = st.sd * (0.2 + (sn * 0.8));
var scoreTh = 0.08 + (sn * 0.28);
if (st.dr < (st.max * 0.3)) { 
minProm *= 0.6;
scoreTh *= 0.8;
}
var fl = [];
for (var f = 0; f < pks.length; f += 1) { 
var passes2 = false;
if ((pks[f].prom >= minProm) && (pks[f].sc >= scoreTh)) { 
passes2 = true;
}
if (((!passes2) && ((pks[f].onset / mx.on) > 0.5)) && (pks[f].sc >= (scoreTh * 0.8))) { 
passes2 = true;
}
if (((!passes2) && (pks[f].sc >= (scoreTh * 1.5))) && (pks[f].prom >= (minProm * 0.5))) { 
passes2 = true;
}
if (passes2) { 
fl.push(pks[f]);
}}
if (cb) { 
cb(0.8, "Suppressing duplicates...");
}
fl.sort(function (a, b) {
return b.sc - a.sc;
});
var ac = [];
var ut = [];
for (var nm = 0; nm < fl.length; nm += 1) { 
var ct = fl[nm].t;
var cl = false;
for (var u = 0; u < ut.length; u += 1) { 
var dd = ct - ut[u];
if (dd < 0) { 
dd = -dd;
}
if (dd < minD) { 
cl = true;
break ;
}}
if (!cl) { 
ac.push(fl[nm]);
ut.push(ct);
}}
if (cb) { 
cb(0.86, "Removing false positives...");
}
ac.sort(function (a, b) {
return a.t - b.t;
});
var ref = [];
for (var fp = 0; fp < ac.length; fp += 1) { 
var peak = ac[fp];
var reject = false;
for (var rr = ref.length - 1; rr >= 0; rr--) { 
var td = peak.t - ref[rr].t;
if (td > 0.2) { 
break ;
}
if ((td > 0.015) && (td < 0.18)) { 
var ampRatio = peak.v / (ref[rr].v + 0.001);
var promRatio = peak.prom / (ref[rr].prom + 0.001);
var onsetRatio = peak.onset / (ref[rr].onset + 0.001);
if ((ampRatio < 0.55) && (promRatio < 0.4)) { 
reject = true;
break ;
}
if (((ampRatio < 0.65) && (promRatio < 0.35)) && (onsetRatio < 0.4)) { 
reject = true;
break ;
}
}}
if (reject) { 
continue ;
}
var sharpNorm = peak.sharp / mx.sh;
var valNorm = peak.v / mx.v;
var onsetNorm = peak.onset / mx.on;
if ((((sharpNorm < 0.04) && (valNorm < 0.4)) && (onsetNorm < 0.15)) && (peak.sc < 0.25)) { 
continue ;
}
if (((peak.engRatio < 0.8) && (peak.sc < 0.2)) && (peak.prom < (minProm * 1.5))) { 
continue ;
}
ref.push(peak);}
if (cb) { 
cb(0.9, "Temporal consistency...");
}
if (ref.length >= 4) { 
var ibis = [];
for (var ib = 1; ib < ref.length; ib += 1) { 
ibis.push(ref[ib].t - ref[ib - 1].t);}
var ibiStats = Sig.stats(ibis);
if ((ibiStats) && (ibiStats.median > 0)) { 
var expectedIBI = ibiStats.median;
var tempRef = [ref[0]];
for (var tc = 1; tc < ref.length; tc += 1) { 
var interval = ref[tc].t - tempRef[tempRef.length - 1].t;
if (interval < (expectedIBI * 0.35)) { 
if (ref[tc].sc > tempRef[tempRef.length - 1].sc) { 
tempRef[tempRef.length - 1] = ref[tc];
}
}
else {
tempRef.push(ref[tc]);
}}
ref = tempRef;
}
}
if (cb) { 
cb(0.93, "Snapping to peaks...");
}
var sr = Math.max(1, Math.floor(data.rate * 0.005));
for (var br = 0; br < ref.length; br += 1) { 
var bi = ref[br].i;
var bv = v[bi];
var bs = bi;
var s1 = (bi - sr) > 0 ? bi - sr : 0;
var s2 = (bi + sr) < (n - 1) ? bi + sr : n - 1;
for (var sr3 = s1; sr3 <= s2; sr3++) { 
if (v[sr3] > bv) { 
bv = v[sr3];
bs = sr3;
}}
ref[br].i = bs;
ref[br].t = t[bs];
ref[br].v = v[bs];}
ref.sort(function (a, b) {
return a.t - b.t;
});
var fin = [];
for (var fd = 0; fd < ref.length; fd += 1) { 
if (!fin.length) { 
fin.push(ref[fd]);
}
else {
if ((ref[fd].t - fin[fin.length - 1].t) >= minD) { 
fin.push(ref[fd]);
}
else {
if (ref[fd].sc > fin[fin.length - 1].sc) { 
fin[fin.length - 1] = ref[fd];
}
}
}}
if (cb) { 
cb(0.96, fin.length + " beats detected.");
}
return fin;
}};
var Mk = {addComp: function (comp, beats, col, pfx, num) {
var mk = comp.markerProperty;
for (var i = 0; i < beats.length; i += 1) { 
var name = num ? pfx + i + 1 : pfx.replace(/\s+$/, "");
var mv = new MarkerValue(name);
if (col > 0) { 
mv.label = col;
}
mk.setValueAtTime(beats[i].t, mv);}
return beats.length;
}, addLayer: function (layer, beats, col, pfx, num) {
var mk = layer.property("ADBE Marker");
for (var i = 0; i < beats.length; i += 1) { 
var name = num ? pfx + i + 1 : pfx.replace(/\s+$/, "");
var mv = new MarkerValue(name);
if (col > 0) { 
mv.label = col;
}
mk.setValueAtTime(beats[i].t, mv);}
return beats.length;
}, delComp: function (c) {
var mk = c.markerProperty;
var n = mk.numKeys;
while (mk.numKeys > 0) {
mk.removeKey(1);
}
return n;
}, delLayer: function (l) {
var mk = l.property("ADBE Marker");
var n = mk.numKeys;
while (mk.numKeys > 0) {
mk.removeKey(1);
}
return n;
}};
buildUI(thisObj);
})(this);
